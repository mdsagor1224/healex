<!-- markdownlint-disable MD041 -->

If you discover a security issue in this repository, please contact us with this email animate@eltonmesquita.com.

Thanks for helping make our open-source projects safe for everyone, we really appreciate it.
